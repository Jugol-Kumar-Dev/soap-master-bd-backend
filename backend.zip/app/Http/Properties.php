<?php


namespace App\Http;


class Properties
{
    public static string $enrollDateFormat = "Y-m-d";

}
