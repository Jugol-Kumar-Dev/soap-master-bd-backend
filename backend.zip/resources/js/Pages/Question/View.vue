<template>
    <h1>View Any Type Document</h1>
</template>

<script>
export default {
    name: "View"
}
</script>

<style scoped>

</style>
