<template>
    <Head title="Dashboard" />
    <section class="app-dashboard">
        <div class="card">
            <div class="card-body border-bottom">
                <h4 class="card-title">Instructor Dashboard</h4>
            </div>
        </div>
    </section>
</template>

<script setup>

</script>