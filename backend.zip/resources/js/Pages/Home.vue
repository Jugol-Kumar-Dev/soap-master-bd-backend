<template>
<Head title="Home" />
</template>

<script>
import FLayout from './Student/FLayout.vue'
export default {
    layout: FLayout,
};
</script>
