<template>
<div class="mb-1">
    <label class="form-label">Basic Select</label>
    <select class="form-select">
        <option>IT</option>
        <option>Blade Runner</option>
        <option>Thor Ragnarok</option>
    </select>
</div>
</template>