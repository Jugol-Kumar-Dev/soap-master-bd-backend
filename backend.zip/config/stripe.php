<?php

    return [

        'stripe_pk' => env("STRIPE_PK"),
        'stripe_sk' => env("STRIPE_SK")



    ];



